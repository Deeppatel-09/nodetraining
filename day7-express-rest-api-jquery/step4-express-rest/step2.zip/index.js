const express = require("express");
const app = express();
const config = require("./config/config.json");
const mongoose = require("mongoose");
const User = require("./model/user.model").User;
const dburl =   `mongodb+srv://${config.dbuser}:${config.dbpass}@${config.dbcluster}.${config.dbstring}.mongodb.net/${config.dbname}?retryWrites=true&w=majority`

// middlewares
app
.use(express.static(__dirname+"/public"))
.use(express.json());

mongoose.connect(dburl)
.then(()=> console.log("DB Connected"))
.catch(error => console.log("Error ", error));

// express routes
// CRUD : Create Read Update Delete

// READ
app.get("/data",(req, res) => {
    User.find().then(dbres=>{
        res.send(dbres);
    });    
});
// CREATE
app.post("/data", (req, res)=>{
    // console.log(req.body);
    let user = new User(req.body);
    user.save()
    .then(dbres => res.send({ "message" : "hello from post route of express"}))
    .catch(error => console.log("Error ", error));
})

app.listen(config.port,config.host, error => {
    if(error) console.log("Error ", error);
    else console.log(`server is now running on ${config.host}:${config.port}`)
});