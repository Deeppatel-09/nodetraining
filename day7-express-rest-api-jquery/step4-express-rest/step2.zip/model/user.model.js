const { default: mongoose } = require("mongoose");

let Schema = mongoose.Schema;
let ObjectId = Schema.ObjectId;
let User = mongoose.model("User", Schema({
    id :  ObjectId,
    firstname : String,
    lastname : String,
    city : String,
    email : String
}));

module.exports.User = User;