const express = require("express");
const app = express();
const config = require("./config/config.json");


// const dburl =   `mongodb+srv://${config.dbuser}:${config.dbpass}@${config.dbcluster}.${config.dbstring}.mongodb.net/${config.dbname}?retryWrites=true&w=majority`
// middlewares
/* 
app.use(function(req, res, next){
    console.log(req.url);
    next();
}); 
*/
// app.use(express.static(__dirname+"/public"));
app.use(express.static(__dirname+"/public"));

// express routes
/* 
app.get("/", function(req, res){
    // res.send("hello from express");
    res.sendFile(__dirname+"/public/index.html");
});
*/

app.listen(config.port,config.host, function(error){
    if(error){
        console.log("Error ", error);
    }else{
        console.log(`server is now running on ${config.host}:${config.port}`)
    }
});